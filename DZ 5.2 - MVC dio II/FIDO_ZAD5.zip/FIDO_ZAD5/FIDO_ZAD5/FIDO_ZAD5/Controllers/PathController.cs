﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FIDO_ZAD5.Models;

namespace FIDO_ZAD5.Controllers
{
    public class PathController : Controller
    {
        // GET: Path/Index
        public ActionResult Index()
        {
            using (fidoModels db = new fidoModels())
            {
                return View(db.path.ToList());
            }
        }

        // GET: Path/Details/id
        public ActionResult Details(int id)
        {
            using (fidoModels db = new fidoModels())
            {

                return View(db.path.Where(x => x.path_UID == id).FirstOrDefault());
            }
           
        }

        // GET: Path/Create
        public ActionResult Create()
        {
            
            return View();
        }

        // POST: Path/Create
        [HttpPost]
        public ActionResult Create(path p)
        {
            try
            {
                using (fidoModels db=new fidoModels())
                {
                    p.lastmodified=DateTime.Now;
                    db.path.Add(p);
                    db.SaveChanges();
                }

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Path/Edit/5
        public ActionResult Edit(int id)
        {
            using (fidoModels db = new fidoModels())
            {
                return View(db.path.Where(x => x.path_UID == id).FirstOrDefault());
            }
        }

        // POST: Path/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, path p)
        {
            try
            {
                using (fidoModels db = new fidoModels())
                {
                    p.lastmodified = DateTime.Now;
                    db.Entry(p).State = EntityState.Modified;
                    db.SaveChanges();
                }
           

                    return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Path/Delete/5
        public ActionResult Delete(int id)
        {
            using (fidoModels db = new fidoModels())
            {

                return View(db.path.Where(x => x.path_UID == id).FirstOrDefault());
            }
        }

        // POST: Path/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, path p)
        {
            try
            {
                using (fidoModels db = new fidoModels())
                {
                    p = db.path.Where(x => x.path_UID == id).FirstOrDefault();
                    db.path.Remove(p);
                    db.SaveChanges();


                }

                    return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
