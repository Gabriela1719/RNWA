﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FIDO_ZAD5.Models;

namespace FIDO_ZAD5.Controllers
{
    public class PanelController : Controller
    {
        // GET: Panel
        public ActionResult Index()
        {
            fidoModels db = new fidoModels ();
            List<panel> Listpanel = db.panel.ToList();
            db.Dispose();
            return View(Listpanel);
        }

        public ActionResult Create()
        {
            return View();
        }

        public ActionResult Add(panel p)
        {
            fidoModels db = new fidoModels();
            p.lastMod = DateTime.Now;
            db.panel.Add(p);
            db.SaveChanges();
            db.Dispose();

            return Redirect("Index");
        }
        public ActionResult Edit(int id)
        {
            fidoModels db = new fidoModels();

            panel p = db.panel.Where(x => x.panel_UID == id).FirstOrDefault();
            ViewBag.Id = p.fk_cabinet_UID;
            cabinet c =  db.cabinet.Where(x => x.cabinet_UID == p.fk_cabinet_UID).FirstOrDefault();
            ViewBag.Name = c.label;
            db.Dispose();
            return View(p);
            
        }
        [HttpPost]
        public ActionResult Edit(int id, panel p)
        {
            fidoModels db = new fidoModels();
            p.lastMod = DateTime.Now;
            db.Entry(p).State = EntityState.Modified;
            db.SaveChanges();

            return RedirectToAction("Index");

        }
        public ActionResult Details(int id)
        {
            fidoModels db = new fidoModels();

            panel p = db.panel.Where(x => x.panel_UID == id).FirstOrDefault();
            db.Dispose();
            return View(p);

        }

        public ActionResult Delete(int id)
        {
            fidoModels db = new fidoModels();

            panel p = db.panel.Where(x => x.panel_UID == id).FirstOrDefault();
            db.Dispose();
            return View(p);

        }
        public ActionResult Remove(panel p)
        {
            fidoModels db = new fidoModels();

            panel e = db.panel.Where(x => x.panel_UID == p.panel_UID).FirstOrDefault();

            db.panel.Remove(e);
            db.SaveChanges();
            db.Dispose();
            return Redirect("Index");

        }
    }
}