﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FIDO_ZAD5.Models;

namespace FIDO_ZAD5.Controllers
{
    public class CabinetController : Controller
    {
        // GET: Cabinet
        public ActionResult Index()
        {
            fidoModels db = new fidoModels();
            List<cabinet> Listcabinet = db.cabinet.ToList();
            db.Dispose();
            return View(Listcabinet);
        }

        public ActionResult Create()
        {
            return View();
        }
        public ActionResult Add(cabinet c)
        {
            fidoModels db = new fidoModels();
            c.lastmodified = DateTime.Now;
            db.cabinet.Add(c);
            db.SaveChanges();
            db.Dispose();

            return Redirect("Index");
        }
        public ActionResult Edit(int id)
        {
            fidoModels db = new fidoModels();

            cabinet c = db.cabinet.Where(x => x.cabinet_UID == id).FirstOrDefault();
            ViewBag.Id = c.fk_storageUnit_UID;
            storageunit s = db.storageunit.Where(x => x.storageUnit_UID == c.fk_storageUnit_UID).FirstOrDefault();
            ViewBag.Name = s.label;
            db.Dispose();
            return View(c);

        }

        [HttpPost]
        public ActionResult Edit(int id, cabinet c)
        {
            fidoModels db = new fidoModels();
            c.lastmodified = DateTime.Now;
            db.Entry(c).State = EntityState.Modified;
            db.SaveChanges();

            return RedirectToAction("Index");

        }
        public ActionResult Details(int id)
        {
            fidoModels db = new fidoModels();

            cabinet c = db.cabinet.Where(x => x.cabinet_UID == id).FirstOrDefault();
            db.Dispose();
            return View(c);

        }

        public ActionResult Delete(int id)
        {
            fidoModels db = new fidoModels();

            cabinet c = db.cabinet.Where(x => x.cabinet_UID == id).FirstOrDefault();
            db.Dispose();
            return View(c);

        }

        public ActionResult Remove(cabinet c)
        {
            fidoModels db = new fidoModels();

            cabinet e = db.cabinet.Where(x => x.cabinet_UID == c.cabinet_UID).FirstOrDefault();

            db.cabinet.Remove(e);
            db.SaveChanges();
            db.Dispose();
            return Redirect("Index");

        }
    }
}